package com.example.project;

import java.util.ArrayList;

public class Semester {
    String semesterName;
    ArrayList<Record> subjects;
    double gpa;

    public Semester(String semesterName){
        this.semesterName = semesterName;
        subjects = new ArrayList<>();
        gpa = 0;
    }

    public void addSubject(Record r){
        subjects.add(r);
        calculateGPA();
    }

    private void calculateGPA(){
        double totalPoints = 0;
        int totalCredits = 0;
        for(Record s : subjects){
            totalPoints += s.gradePoint * s.credits;
            totalCredits += s.credits;
        }
        gpa = totalCredits == 0 ? 0 : totalPoints / totalCredits;
    }
}
