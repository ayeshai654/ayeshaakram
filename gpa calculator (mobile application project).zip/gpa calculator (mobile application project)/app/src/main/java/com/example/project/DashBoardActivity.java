package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class DashBoardActivity extends AppCompatActivity {

    TextView tvWelcome;
    Button btnGPA, btnCGPA, btnHistory;

    int userId;
    String userName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        tvWelcome = findViewById(R.id.tvWelcome);
        btnGPA = findViewById(R.id.btnGPA);
        btnCGPA = findViewById(R.id.btnCGPA);
        btnHistory = findViewById(R.id.btnHistory);

        // Receive data from LoginActivity
        userId = getIntent().getIntExtra("userId", -1);
        userName = getIntent().getStringExtra("userName");

        // Set welcome text
        if (userName != null) {
            tvWelcome.setText("Welcome, " + userName);
        }

        // GPA Calculator
        btnGPA.setOnClickListener(v -> {
            Intent intent = new Intent(DashBoardActivity.this, GPACalculatorActivity.class);
            intent.putExtra("userId", userId);
            startActivity(intent);
        });

        // CGPA Calculator
        btnCGPA.setOnClickListener(v -> {
            Intent intent = new Intent(DashBoardActivity.this, CGPAActivity.class);
            intent.putExtra("userId", userId);
            startActivity(intent);
        });

        // History Button
        btnHistory.setOnClickListener(v -> {
            Intent intent = new Intent(DashBoardActivity.this, HistoryActivity.class);
            intent.putExtra("userId", userId);
            startActivity(intent);
        });
    }
}
