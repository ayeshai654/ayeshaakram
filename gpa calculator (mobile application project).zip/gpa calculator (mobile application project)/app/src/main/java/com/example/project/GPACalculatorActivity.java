package com.example.project;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class GPACalculatorActivity extends AppCompatActivity {

    EditText etSubject, etMarks, etTotal, etCredit;
    Button btnAdd, btnCalc;
    TextView tvResult;

    ArrayList<Integer> marksList = new ArrayList<>();
    ArrayList<Integer> totalList = new ArrayList<>();
    ArrayList<Integer> creditList = new ArrayList<>();

    // Database
    DatabaseHelper db;
    int userId = 1; // Example userId, replace with actual logged-in user ID

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gpacalculator);

        etSubject = findViewById(R.id.etSubject);
        etMarks = findViewById(R.id.etMarks);
        etTotal = findViewById(R.id.etTotal);
        etCredit = findViewById(R.id.etCredit);

        btnAdd = findViewById(R.id.btnAdd);
        btnCalc = findViewById(R.id.btnCalc);
        tvResult = findViewById(R.id.tvResult);

        db = new DatabaseHelper(this);

        btnAdd.setOnClickListener(v -> {
            // Input validation
            if(etMarks.getText().toString().isEmpty() ||
                    etTotal.getText().toString().isEmpty() ||
                    etCredit.getText().toString().isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            int marks = Integer.parseInt(etMarks.getText().toString());
            int total = Integer.parseInt(etTotal.getText().toString());
            int credit = Integer.parseInt(etCredit.getText().toString());

            marksList.add(marks);
            totalList.add(total);
            creditList.add(credit);

            Toast.makeText(this, "Subject Added!", Toast.LENGTH_SHORT).show();

            etMarks.setText("");
            etTotal.setText("");
            etCredit.setText("");
        });

        btnCalc.setOnClickListener(v -> calculateGPA());
    }

    private void calculateGPA() {

        if(marksList.size() == 0) {
            Toast.makeText(this, "No subjects added!", Toast.LENGTH_SHORT).show();
            return;
        }

        double totalQuality = 0;
        double totalCredits = 0;

        for (int i = 0; i < marksList.size(); i++) {
            int marks = marksList.get(i);
            int total = totalList.get(i);
            int credit = creditList.get(i);

            String gradeLetter = getGradeLetter(marks, total);
            double gradePoint = getGradePoint(gradeLetter);

            double quality = gradePoint * credit;

            totalQuality += quality;
            totalCredits += credit;
        }

        if(totalCredits == 0) {
            Toast.makeText(this, "Total credits cannot be zero!", Toast.LENGTH_SHORT).show();
            return;
        }

        double gpa = totalQuality / totalCredits;
        String gpaString = String.format("%.2f", gpa);

        tvResult.setText("Your GPA: " + gpaString);

        // ---- SAVE TO DATABASE ----
        boolean inserted = db.insertHistory(userId, gpaString, null); // CGPA null
        if(inserted) {
            Toast.makeText(this, "GPA saved in history!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Failed to save GPA!", Toast.LENGTH_SHORT).show();
        }
    }

    // MARKS → GRADE LETTER (A / B / C / F)
    private String getGradeLetter(int marks, int total) {
        double percentage = (marks * 100.0) / total;

        if (percentage >= 80) return "A";
        else if (percentage >= 65) return "B";
        else if (percentage >= 50) return "C";
        else return "F";
    }

    // GRADE → GRADE POINT
    private double getGradePoint(String grade) {
        switch (grade) {
            case "A": return 4.0;
            case "B": return 3.0;
            case "C": return 2.0;
            default: return 0.0;
        }
    }
}
