package com.example.project;

public class Subject {
    String subjectName;
    int credits;
    int marks;
    double gradePoint;

    public Subject(String subjectName, int credits, int marks, double gradePoint) {
        this.subjectName = subjectName;
        this.credits = credits;
        this.marks = marks;
        this.gradePoint = gradePoint;
    }
}
