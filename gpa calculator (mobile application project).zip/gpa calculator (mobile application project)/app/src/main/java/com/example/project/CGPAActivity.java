package com.example.project;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class CGPAActivity extends AppCompatActivity {

    EditText etSemGpa, etSemCredits;
    Button btnAddSem, btnCalcCgpa;
    TextView tvCgpaResult;

    ArrayList<Double> gpaList = new ArrayList<>();
    ArrayList<Integer> creditList = new ArrayList<>();

    // Database
    DatabaseHelper db;
    int userId = 1; // Replace with actual logged-in user ID

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cgpacalculator);

        etSemGpa = findViewById(R.id.etSemGpa);
        etSemCredits = findViewById(R.id.etSemCredits);
        btnAddSem = findViewById(R.id.btnAddSem);
        btnCalcCgpa = findViewById(R.id.btnCalcCgpa);
        tvCgpaResult = findViewById(R.id.tvCgpaResult);

        db = new DatabaseHelper(this);

        btnAddSem.setOnClickListener(v -> {
            // Input validation
            if(etSemGpa.getText().toString().isEmpty() ||
                    etSemCredits.getText().toString().isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            double gpa = Double.parseDouble(etSemGpa.getText().toString());
            int credits = Integer.parseInt(etSemCredits.getText().toString());

            gpaList.add(gpa);
            creditList.add(credits);

            Toast.makeText(this, "Semester Added!", Toast.LENGTH_SHORT).show();

            etSemGpa.setText("");
            etSemCredits.setText("");
        });

        btnCalcCgpa.setOnClickListener(v -> calculateCGPA());
    }

    private void calculateCGPA() {

        if(gpaList.size() == 0) {
            Toast.makeText(this, "No semesters added!", Toast.LENGTH_SHORT).show();
            return;
        }

        double totalQuality = 0;
        double totalCredits = 0;

        for (int i = 0; i < gpaList.size(); i++) {
            double gpa = gpaList.get(i);
            int credit = creditList.get(i);

            totalQuality += gpa * credit;
            totalCredits += credit;
        }

        if(totalCredits == 0) {
            Toast.makeText(this, "Total credits cannot be zero!", Toast.LENGTH_SHORT).show();
            return;
        }

        double cgpa = totalQuality / totalCredits;
        String cgpaString = String.format("%.2f", cgpa);

        tvCgpaResult.setText("Your CGPA: " + cgpaString);

        // ---- SAVE TO DATABASE ----
        boolean inserted = db.insertHistory(userId, null, cgpaString); // GPA null
        if(inserted) {
            Toast.makeText(this, "CGPA saved in history!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Failed to save CGPA!", Toast.LENGTH_SHORT).show();
        }
    }
}
