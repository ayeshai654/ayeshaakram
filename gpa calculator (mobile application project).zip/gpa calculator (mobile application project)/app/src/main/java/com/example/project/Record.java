package com.example.project;

public class Record {
    String semester;
    String subjectName;
    int credits;
    int marks;
    double gradePoint;

    public Record(String semester, String subjectName, int credits, int marks, double gradePoint){
        this.semester = semester;
        this.subjectName = subjectName;
        this.credits = credits;
        this.marks = marks;
        this.gradePoint = gradePoint;
    }
}
