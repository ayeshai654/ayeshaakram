package com.example.project;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "gpa_db";
    private static final int DB_VERSION = 1;

    // USERS TABLE
    public static final String TABLE_USERS = "Users";
    public static final String USER_ID = "id";
    public static final String USER_NAME = "name";
    public static final String USER_EMAIL = "email";
    public static final String USER_PASSWORD = "password";

    // HISTORY TABLE
    public static final String TABLE_HISTORY = "History";
    public static final String HIST_ID = "id";
    public static final String HIST_USER_ID = "user_id";
    public static final String HIST_GPA = "gpa";
    public static final String HIST_CGPA = "cgpa";
    public static final String HIST_DATE = "date";

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create Users table
        String createUsers = "CREATE TABLE " + TABLE_USERS + "(" +
                USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                USER_NAME + " TEXT, " +
                USER_EMAIL + " TEXT UNIQUE, " +
                USER_PASSWORD + " TEXT)";
        db.execSQL(createUsers);

        // Create History table
        String createHistory = "CREATE TABLE " + TABLE_HISTORY + "(" +
                HIST_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                HIST_USER_ID + " INTEGER, " +
                HIST_GPA + " TEXT, " +
                HIST_CGPA + " TEXT, " +
                HIST_DATE + " TEXT)";
        db.execSQL(createHistory);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_HISTORY);
        onCreate(db);
    }

    // Insert a new user
    public long insertUser(String name, String email, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(USER_NAME, name.trim());
        cv.put(USER_EMAIL, email.trim());
        cv.put(USER_PASSWORD, password.trim());
        return db.insert(TABLE_USERS, null, cv);
    }

    // Check login
    public Cursor checkUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_USERS +
                        " WHERE " + USER_EMAIL + "=? AND " + USER_PASSWORD + "=?",
                new String[]{email.trim(), password.trim()});
    }

    // Add history record
    public boolean insertHistory(int userId, String gpa, String cgpa) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(HIST_USER_ID, userId);
        cv.put(HIST_GPA, gpa);
        cv.put(HIST_CGPA, cgpa);

        String date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
        cv.put(HIST_DATE, date);

        long result = db.insert(TABLE_HISTORY, null, cv);
        return result != -1;
    }

    // Get history for specific user
    public Cursor getHistory(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_HISTORY +
                        " WHERE " + HIST_USER_ID + "=? ORDER BY " + HIST_ID + " DESC",
                new String[]{String.valueOf(userId)});
    }
}
