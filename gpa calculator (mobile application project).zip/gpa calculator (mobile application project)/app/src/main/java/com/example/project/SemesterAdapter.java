package com.example.project;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class SemesterAdapter extends RecyclerView.Adapter<SemesterAdapter.ViewHolder> {

    ArrayList<Semester> semesters;

    public SemesterAdapter(ArrayList<Semester> semesters){
        this.semesters = semesters;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(android.R.layout.simple_list_item_2, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Semester s = semesters.get(position);
        holder.tv1.setText(s.semesterName + " | GPA: " + String.format("%.2f", s.gpa));

        StringBuilder sb = new StringBuilder();
        for(Record r : s.subjects){
            sb.append(r.subjectName).append("(").append(r.credits).append("), ");
        }
        if(sb.length() > 0) sb.setLength(sb.length() - 2);

        holder.tv2.setText(sb.toString());
    }

    @Override
    public int getItemCount() {
        return semesters.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder{
        TextView tv1, tv2;
        public ViewHolder(@NonNull View itemView){
            super(itemView);
            tv1 = itemView.findViewById(android.R.id.text1);
            tv2 = itemView.findViewById(android.R.id.text2);
        }
    }
}
