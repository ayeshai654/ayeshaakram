package com.example.project;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.RadioButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class HistoryActivity extends AppCompatActivity {

    RadioButton rbGpa, rbCgpa;
    RecyclerView rvHistory;
    HistoryAdapter adapter;
    DatabaseHelper db;
    int userId;

    ArrayList<String> gpaList = new ArrayList<>();
    ArrayList<String> cgpaList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        db = new DatabaseHelper(this);
        userId = getIntent().getIntExtra("userId", -1);
        Toast.makeText(this, "UserID = " + userId, Toast.LENGTH_SHORT).show();  // DEBUG

        rbGpa = findViewById(R.id.rbGpa);
        rbCgpa = findViewById(R.id.rbCgpa);
        rvHistory = findViewById(R.id.rvHistory);

        adapter = new HistoryAdapter(new ArrayList<>());
        rvHistory.setLayoutManager(new LinearLayoutManager(this));
        rvHistory.setAdapter(adapter);

        // default show GPA history
        loadGpaHistory();

        rbGpa.setOnClickListener(v -> loadGpaHistory());
        rbCgpa.setOnClickListener(v -> loadCgpaHistory());
    }

    private void loadGpaHistory() {
        ArrayList<String> list = new ArrayList<>();
        Cursor cursor = db.getHistory(userId); // fetch from History table
        if(cursor != null && cursor.moveToFirst()) {
            do {
                String gpa = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.HIST_GPA));
                String date = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.HIST_DATE));
                list.add("GPA: " + gpa + " | Date: " + date);
            } while(cursor.moveToNext());
            cursor.close();
        }
        if(list.isEmpty()) {
            Toast.makeText(this, "No GPA records found", Toast.LENGTH_SHORT).show();
        }
        adapter.updateList(list);
    }

    private void loadCgpaHistory() {
        ArrayList<String> list = new ArrayList<>();
        Cursor cursor = db.getHistory(userId); // same table
        if(cursor != null && cursor.moveToFirst()) {
            do {
                String cgpa = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.HIST_CGPA));
                String date = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.HIST_DATE));
                list.add("CGPA: " + cgpa + " | Date: " + date);
            } while(cursor.moveToNext());
            cursor.close();
        }
        if(list.isEmpty()) {
            Toast.makeText(this, "No CGPA records found", Toast.LENGTH_SHORT).show();
        }
        adapter.updateList(list);
    }

}
