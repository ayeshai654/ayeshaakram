#include <stdio.h>
#include <stdbool.h>
#include <unistd.h>
#include <sys/ioctl.h>

#define P 5
#define R 3

int available[R];
int max[P][R];
int allocation[P][R];
int need[P][R];

#define GREEN "\033[1;32m"
#define RED "\033[1;31m"
#define YELLOW "\033[1;33m"
#define BLUE "\033[1;34m"
#define RESET "\033[0m"
int getTerminalWidth() {
    struct winsize w;
    ioctl(0, TIOCGWINSZ, &w);
    return w.ws_col > 0 ? w.ws_col : 80;
}

void printCentered(const char *text) {
    int width = getTerminalWidth();
 int len = 0;
    while (text[len] != '\0') len++;
    int padding = (width - len) / 2;
    for (int i = 0; i < padding; i++) printf(" ");
    printf("%s\n", text);
}

void calculateNeed() {
    for (int i = 0; i < P; i++)
        for (int j = 0; j < R; j++)
            need[i][j] = max[i][j] - allocation[i][j];
}

bool isSafe() {
    int work[R];
    bool finish[P] = {false};
    int safeSeq[P];
    int count = 0;

    for (int i = 0; i < R; i++)
        work[i] = available[i];
 printf(YELLOW "\n");
    printCentered("  Checking system safety...");
    printf(RESET);
    sleep(1);

    while (count < P) {
        bool found = false;
        for (int p = 0; p < P; p++) {
            if (!finish[p]) {
                int j;
                for (j = 0; j < R; j++)
                    if (need[p][j] > work[j])
                        break;

                if (j == R) {
                    char msg[50];
                    sprintf(msg, "  Process P%d executed safely", p);
                    printf(GREEN);
                    printCentered(msg);
                    printf(RESET);
                    sleep(1);

                    for (int k = 0; k < R; k++)
                        work[k] += allocation[p][k];
 safeSeq[count++] = p;
                    finish[p] = true;
                    found = true;
                }
            }
        }

        if (!found) {
            printf(RED "\n");
            printCentered("  DEADLOCK DETECTED!");
            printCentered("System is NOT in safe state.");
            printf(RESET "\n");
            return false;
        }
    }

    printf( "\n");
    printCentered("  >>--System is in SAFE STATE!--<<");
    printf(RESET);
    printf(BLUE);
    printf("\n");
    printf(RESET);
    printf(BLUE);
 printf("\nSafe Sequence: ");
    for (int i = 0; i < P; i++)
        printf("P%d ", safeSeq[i]);
    printf(RESET "\n");
    return true;
}

int main() {
    printf("\n");
    printf(BLUE);
    printCentered("==================================================");
    printf(YELLOW);
    printCentered("  DEADLOCK DETECTION GAME");
    printf(BLUE);
    printCentered("==================================================");
    printf(RESET "\n");

    printf("Enter Available Resources (R1 R2 R3 - VALUES WITH SPACES): ");
    for (int i = 0; i < R; i++)
        scanf("%d", &available[i]);

    printf("\nEnter Max Matrix (%d x %d):\n", P, R);
    for (int i = 0; i < P; i++)
        for (int j = 0; j < R; j++)
            scanf("%d", &max[i][j]);
 printf("\nEnter Allocation Matrix (%d x %d):\n", P, R);
    for (int i = 0; i < P; i++)
        for (int j = 0; j < R; j++)
            scanf("%d", &allocation[i][j]);

    calculateNeed();

    printf(YELLOW "\n");
    printCentered("  Calculating 'NEED' Matrix...");
    printf(RESET "\n");
    sleep(1);

    printCentered("Need Matrix:");
    for (int i = 0; i < P; i++) {
        for (int j = 0; j < R; j++)
            printf("%d ", need[i][j]);
        printf("\n");
    }

    printf(YELLOW "\n");
    printCentered("  Starting safety check...");
    printf(RESET "\n");
    sleep(1);

    isSafe();
 printf(BLUE "\n");
    printCentered("==================================================");
    printf(YELLOW);
    printCentered("  Simulation Complete!");
    printf(BLUE);
    printCentered("==================================================");
    printf(RESET "\n\n");

    return 0;
}